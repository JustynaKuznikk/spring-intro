package pl.sda.projects.adverts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvertsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvertsApplication.class, args);
	}

}
